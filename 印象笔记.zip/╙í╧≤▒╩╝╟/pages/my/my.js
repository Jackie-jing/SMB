// pages/my/my.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfos: {}
  },

  // 事件处理函数
  getUserInfo: function(){
    

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    wx.getUserInfo({
      success(res) {
        const userInfo = res.userInfo
        const nickName = userInfo.nickName
        const avatarUrl = userInfo.avatarUrl
        const gender = userInfo.gender // 性别 0：未知、1：男、2：女
        const province = userInfo.province
        const city = userInfo.city
        const country = userInfo.country

  
        //console.log(userInfo)
        //把拿到的数据通过setData更新到 data部分然后在前端显示
        that.setData({
          "userInfos.nickName": nickName,
          "userInfos.avantar": avatarUrl,
          "userInfos.gender": gender,
          "userInfos.city": city,
          "userInfos.country": country,
          "userInfos.province": province
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})